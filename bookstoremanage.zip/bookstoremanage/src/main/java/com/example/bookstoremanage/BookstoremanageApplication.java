package com.example.bookstoremanage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoremanageApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookstoremanageApplication.class, args);
		System.out.println("connected....");
	}

}
