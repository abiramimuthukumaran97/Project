package com.example.bookstoremanage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoremanageApplicationTests {

	@Test
	void contextLoads() {
	}

}
